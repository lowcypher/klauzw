<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema CADMO - II</title>
    <!-- Adicione os links para o Bootstrap CSS e JavaScript -->

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!--<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> -->

    <!-- Adicione o link para o Font Awesome -->
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> -->
    <link href="fonts/css/all.css" rel="stylesheet">
    <!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.7/css/all.css"> -->
    <link rel="stylesheet" href="fontawesome/css/all.min.css">

    <!--<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">Página Inicial</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="cadastro_cliente.php" title="Cadastrar Cliente"><i class="fas fa-user-plus fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="listar_clientes.php" title="Clientes"><i class="fas fa-users fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <!--<a class="nav-link" href="orcamento2b.php" title="Cadastrar Orçamento"><i class="fas fa-file-signature fa-2x"></i></a> -->
                <a class="nav-link" href="orcamento2b.php" title="Cadastrar Orçamento"><i class="fas fa-file-invoice fa-2x"></i></a>
            </li>
            <li class="nav-item"> 
                <a class="nav-link" href="busca_orcamento2.php" title="Orçamentos"><i class="fas fa-file-alt fa-2x"></i></a>
            </li> 
            <li class="nav-item"> 
                <a class="nav-link" href="controle/listar.php" title="Controle"><i class="fas fa-table fa-2x"></i></a>
            </li> 
            <li class="nav-item">
                <!--<a class="nav-link" href="mostrar_atividades_codigo.php" title="Buscar Históricos"><i class="fas fa-file-alt fa-2x"></i></a> -->
                <a class="nav-link" href="mostrar_atividades_codigo.php" title="Buscar Históricos"><i class="fas fa-filter fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <!--<a class="nav-link" href="z_listar_atividades.php" title="Todos Históricos"><i class="fas fa-file-alt fa-2x"></i></a>-->
                <a class="nav-link" href="z_listar_atividades.php" title="Todos Históricos"><i class="fas fa-list-ol fa-2x"></i></a>
            </li>            
            <li class="nav-item">
                <a class="nav-link" href="forms/checklist.php" title="Checklist"><i class="fas fa-tasks fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="forms/levantamento.php" title="Levantamento"><i class="fas fa-list-alt fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="listar_informes.php" title="Informes L"><i class="fas fa-file-alt fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="listar_informes_r.php" title="Informes R"><i class="fas fa-file-alt fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <!--<a class="nav-link" href="listar_recibos.php" title="Recibos"><i class="fas fa-receipt fa-2x"></i></a> -->
                <a class="nav-link" href="listar_recibos.php" title="Recibos"><i class="fas fa-money-check fa-2x"></i></a>
            </li>            
            <li class="nav-item">
                <!--<a class="nav-link" href="listar_livro.php" title="Retirada"><i class="fas fa-file-signature fa-2x"></i></a> -->
                <a class="nav-link" href="listar_livro.php" title="Retirada"><i class="fas fa-address-book fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="todas-tabelas.php" title="SubSistemas"><i class="fas fa-table-list fa-2x"></i></a>
            </li>        
            <li class="nav-item">
                <a class="nav-link" href="documentos_lista.php" title="Docs-Clientes"><i class="fas fa-file-alt fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="laudos_lista.php" title="Laudos"><i class="fas fa-file-pdf fa-2x"></i></a>
            </li>            
            <li class="nav-item">
                <a class="nav-link" href="forms/declaracoes.php" title="Declarações"><i class="fas fa-file-alt fa-2x"></i></a>
            </li>  
            <li class="nav-item">
                <a class="nav-link" href="forms/docs_ncmo/" title="Anexos NCMO"><i class="fas fa-file-pdf fa-2x"></i></a>
            </li>  
            <li class="nav-item">
                <!--<a class="nav-link" href="relatorios/relatorios.php" title="Relatórios"><i class="fas fa-file-pdf fa-2x"></i></a> -->
                <a class="nav-link" href="relatorios/relatorios.php" title="Relatórios"><i class="fas fa-chart-pie fa-2x"></i></a>
            </li>  
            <li class="nav-item">
                <!--<a class="nav-link" href="z_todos_orcamentos.php" title="Lista Status"><i class="fas fa-book fa-2x"></i></a>-->
                <!--<a class="nav-link" href="z_todos_orcamentos.php" title="Lista Status"><i class="fas fa-triangle-exclamation fa-2x"></i></a> -->
                <a class="nav-link" href="z_todos_orcamentos.php" title="Lista Status"><i class="fas fa-check-double fa-2x"></i></a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="estoque/" title="Controle Estoque" target="_blank"><i class="fas fa-box-archive fa-2x"></i></a>
            </li> 
            <li class="nav-item">
                <!--<a class="nav-link" href="estacionamento/formulario.php" title="Estacionamento" target="_blank"><i class="fas fa-solid fa-car fa-2x"></i></a> -->
                <a class="nav-link" href="estacionamento/formulario.php" title="Estacionamento"><i class="fas fa-solid fa-car fa-2x"></i></a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="#" data-toggle="modal" data-target="#sobreModal" title="Sobre"><i class="fas fa-info-circle fa-2x"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../logout.php" title="Sair"><i class="fas fa-sign-out-alt fa-2x"></i></a>
            </li>
        </ul>
    </div>
</nav>

<!-- Modal -->
<div class="modal fade" id="sobreModal" tabindex="-1" role="dialog" aria-labelledby="sobreModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h2 class="modal-title" id="sobreModalLabel"><b>Sistema de Catálogo Digital de Micro Organismos - CADMO - II</b></h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Conteúdo do modal -->
                <h3>Sistema em desenvolvimento e atualizações</h3>
                <p>Este sistema tem por finalidade facilitar o cadastro das solicitações de linhagens recebidas pelo NCMO.</p>
    <p>O registro das solicitações são feitas por meio de formulários que trazem algumas informações cadastradas, reduzindo
    o tempo de preenchimento dos documentos bem como possíveis erros de digitação dos dados.</p>
    <p>Esta versão <i><b>0.7.8</b></i> de <strong>2024-06-30</strong> possui emissão dos documentos: orçamento, doação, 
    informe liofilizado, informe reativada, checklist, ficha estoque, registro de retirada, solicitação de emissão de recibos, 
    declarações de transporte e material, histórico de andamento do pedido/orçamento, ficha de controle de clientes do mês (ou meses)</p>
    <p>Um módulo (em testes) para criação do checklist sendo preenchido os campos no próprio sistema, conforme o processo percorre suas fases.</p>
    <p>Foram criados módulos de relatórios básicos. Nesta versão <i><b>0.7.8</b></i>, foram adicionados mais 2 
    (na versão <i><b>0.7.5</b></i> eram 3) ficando com 5 tipos de relatórios. (Obs: Os relatórios estão em desenvolvimento e correções).</p>
    <p>Foi adicionado um módulo de controle de estoque simples, que está fora do sistema mas pode ser acessado por ele. </p>
    <p>Um ajuste feito no cadastro de orçamento, onde pode ser feito o registro do cliente e data, tendo os demais dados com sua 
        inclusão posterior. Isso permite gerar o número do pedido/orçamento e então gerar os documentos iniciais
         "Checklist" e "Ficha de Levantamento" com os códigos já registrados.</p>
    <p>O sistema possui também uma área para armazenar os documentos enviados pelos clientes com identificação e 
        laudos de cada pedido/orçamento/doação.</p>
    <p>Possui área com os documentos e anexos necessários para o processo de fornecimento de linhagens</p>
<br>
<p style="line-height: 0.3;" align="center">Desenvolvido em PHP, MySQL, JavaScript e Bootstrap.</p>
<p style="line-height: 0.3;" align="center">Utiliza biblioteca mPDF para gerar os PDFs dos documentos.</p>

<br>
    <p align="center"><b>Desenvolvedor: Mario Medeiros - Disaster Developer</b></p>
    
    <p style="line-height: 0.3;" align="center"><i><b>Data: 2024-06-30 - Versão: 0.7.8</b></i></p>
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-05-25 - Versão: 0.7.7</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-05-18 - Versão: 0.7.6</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-03-10 - Versão: 0.7.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-25 - Versão: 0.6.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-18 - Versão: 0.5.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-17 - Versão: 0.5.0</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-13 - Versão: 0.3.0</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2023-09-04 - Versão: 0.2.0</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2023-08-10 - Versão; 0.1.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2023-08-01 - Versão: 0.1.0</i></p>  


    <!--<p style="line-height: 0.3;" align="center"><i>Data: 2024-03-10 - Versão: 0.7.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-25 - Versão: 0.6.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-18 - Versão: 0.5.5</i></p>  
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-17 - Versão: 0.5.0</i></p>
    <p style="line-height: 0.3;" align="center"><i>Data: 2024-02-13 - Versão: 0.3.0</i></p> -->  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

</body>
</html>



<!--
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">Página Inicial</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="cadastro_cliente.php">Cadastrar Cliente</a>        
      </li>
      <li class="nav-item">
        <a class="nav-link" href="listar_clientes.php">Listar Clientes</a>        
      </li>      
      <li class="nav-item">
        <!--<a class="nav-link" href="orcamento2a.php">Cadastrar Orçamento<span class="sr-only">(current)</span></a> -->
        <!--<a class="nav-link" href="orcamento2a.php">Cadastrar Orçamento</a> -->
        <!--<a class="nav-link" href="orcamento2b.php">Cadastrar Orçamento</a>            
      </li>
      <li class="nav-item">
        <a class="nav-link" href="busca_orcamento2.php">Lista de Orçamentos Registrados</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="listar_informes.php">Lista de Informes Registrados</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Sobre</a>
      </li>      
      <li class="nav-item">
        <!--<a class="nav-link" href="visualizar_registro2a.php">Página 3</a> -->
      <!--</li>
    </ul>
  </div>
</nav>
-->