<?php
// Configurações de conexão com o banco de dados
$host = 'localhost';      // Nome do servidor de banco de dados
$dbname = 'password_manager'; // Nome do banco de dados
$username = '';    // Nome de usuário do banco de dados
$password = '';      // Senha do banco de dados

// Criando a conexão
$conn = new mysqli($host, $username, $password, $dbname);

// Verificando se a conexão foi bem-sucedida
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Definindo o charset para garantir que a comunicação com o banco de dados funcione corretamente com caracteres especiais
$conn->set_charset("utf8");

?>
