<?php
include('conexao.php');

// Verifica se o proprietário já foi cadastrado
$sql_check = "SELECT * FROM proprietario LIMIT 1";
$result = $conn->query($sql_check);

if ($result->num_rows > 0) {
    // Se já houver um registro, redireciona para a página de login
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);  // Hash da senha

    $sql = "INSERT INTO proprietario (nome, sobrenome, email, senha) 
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nome, $sobrenome, $email, $senha);
    
    if ($stmt->execute()) {
        echo "Proprietário cadastrado com sucesso.";
        // Redireciona para a página de login
        header("Location: login.php");
        exit();
    } else {
        echo "Erro: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!-- HTML Formulário de Cadastro -->
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro do Proprietário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Define a cor suave de fundo para o modal */
        .modal-content {
            background-color: rgba(255, 255, 255, 0.9); /* Cor branca com 90% de opacidade */
            border-radius: 8px; /* Opcional: adiciona bordas arredondadas */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Opcional: adiciona sombra ao redor do modal */
        }

        /* Define a cor do fundo do modal backdrop */
        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.5); /* Cor preta com 50% de opacidade */
        }
    </style>
    <style>
        /* Define o estilo da imagem de fundo */
        body {
            /* Define a imagem de fundo */
            background-image: url('logo.png');
            
            /* Faz com que a imagem fique fixa na tela */
            background-attachment: fixed;

            /* Faz com que a imagem cubra toda a área da página */
            background-size: cover;

            /* Centraliza a imagem de fundo */
            background-position: center;

            /* Define a opacidade do fundo */
            background-repeat: no-repeat;

            /* Define uma cor de fundo semitransparente para melhorar a legibilidade do texto */
            /*background-color: rgba(255, 255, 255, 0.5); /* Altere a cor e a opacidade conforme necessário */
        }
    </style>
    <style>
        /*body {
            background-color: #d4e5f6; /* Cor de fundo */
            /*display: flex;
            flex-direction: column;
            min-height: 100vh;
        }*/
        .container {
            flex: 1;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.2);
        }
        .navbar-dark .navbar-nav .nav-link {
            color: #ffffff;
        }
        body {
            background-color: #d4e5f6; /* Cor de fundo */
            display: flex;
            justify-content: center;
            flex-direction: column;
            /*align-items: center;*/
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Cadastro do Proprietário</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome:</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <div class="mb-3">
            <label for="sobrenome" class="form-label">Sobrenome:</label>
            <input type="text" class="form-control" id="sobrenome" name="sobrenome" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="senha" class="form-label">Senha:</label>
            <input type="password" class="form-control" id="senha" name="senha" required>
        </div>
        <button type="submit" class="btn btn-primary">Cadastrar</button>
    </form>
</div>
</body>
</html>
