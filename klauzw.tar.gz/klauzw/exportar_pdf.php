<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once 'conexao.php';

use Mpdf\Mpdf;

// Função para descriptografar a senha
function decryptPassword($encryptedPassword) {
    $cipher = "aes-256-cbc";
    $key = "senha-a-ser-definida"; // A mesma chave secreta usada na criptografia
    $data = base64_decode($encryptedPassword);
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = substr($data, 0, $ivlen);
    $ciphertext = substr($data, $ivlen);
    return openssl_decrypt($ciphertext, $cipher, $key, 0, $iv);
}

// Consulta os dados da tabela "registros"
$query = "SELECT * FROM registros";
$result = $conn->query($query);

$html = '
<h2 style="text-align: center;">Relatório de Registros</h2>
<table border="1" style="width: 100%; border-collapse: collapse; text-align: center;">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Usuário</th>
            <th>Senha</th>
            <th>Descrição</th>
            <th>Site</th>
            <th>Obs:</th>
        </tr>
    </thead>
    <tbody>';

while ($row = $result->fetch_assoc()) {
    // Descriptografa a senha
    $senhaDescriptografada = decryptPassword($row['senha']);
    
    $html .= '<tr>
                <td>' . $row['nome'] . '</td>
                <td>' . $row['nome_usuario'] . '</td>
                <td>' . $senhaDescriptografada . '</td>
                <td>' . $row['descricao'] . '</td>
                <td>' . $row['site'] . '</td>                
                <td>' . $row['obs'] . '</td>
              </tr>';
}

$html .= '
    </tbody>
</table>';

// Configurações do mPDF
$mpdf = new Mpdf(['orientation' => 'L']); // L para paisagem

// Cabeçalho
$mpdf->SetHeader('Lista de Serviços e Senhas|Gerado em {DATE j-m-Y}|Página {PAGENO}');

// Rodapé
$mpdf->SetFooter('© 2024 Klauz-W - <a class="text-black" href="https://www.mariomedeiros.eti.br" target="_blank">Mario Medeiros - Disaster Developer</a> ');

// Marca d'água
$pageWidth = $mpdf->w;
$pageHeight = $mpdf->h;
$mpdf->SetWatermarkImage('logo.png', 0.3, [$pageWidth, $pageHeight]);
$mpdf->showWatermarkImage = true;

// Adiciona o conteúdo HTML
$mpdf->WriteHTML($html);

// Visualiza o PDF no navegador
$mpdf->Output('registros.pdf', 'I');
?>
