<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

include('conexao.php');

// Verifica se há um termo de busca
$searchTerm = isset($_POST['search']) ? trim($_POST['search']) : '';

// Ajusta a consulta SQL com base no termo de busca
$sql = "SELECT * FROM registros";
if ($searchTerm) {
    $sql .= " WHERE nome LIKE ?";
}

$stmt = $conn->prepare($sql);

// Adiciona o parâmetro de busca se existir
if ($searchTerm) {
    $searchTerm = "%" . $conn->real_escape_string($searchTerm) . "%";
    $stmt->bind_param("s", $searchTerm);
}

$stmt->execute();
$result = $stmt->get_result();

function decryptPassword($encryptedPassword) {
    $cipher = "aes-256-cbc";
    $key = "senha-a-ser-definida"; // Mesma chave usada para criptografia
    $data = base64_decode($encryptedPassword);
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = substr($data, 0, $ivlen);
    $ciphertext = substr($data, $ivlen);
    return openssl_decrypt($ciphertext, $cipher, $key, 0, $iv);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .modal-content {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.5);
        }

        body {
            background-image: url('logo.png');
            background-attachment: fixed;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-color: rgba(255, 255, 255, 0.5);
        }

        footer {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .navbar-dark .navbar-nav .nav-link {
            color: #ffffff;
        }

        .senha {
            position: relative;
            cursor: pointer;
        }

        .senha::after {
            content: "**********";
            color: #000;
        }

        .senha:hover::after {
            content: attr(data-senha);
            color: #000;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalSobre">Sobre</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-danger text-white" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2>Gerenciador de Senhas</h2>
        
        <!-- Formulário de Busca -->
        <form method="POST" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Buscar por nome" value="<?php echo htmlspecialchars($searchTerm, ENT_QUOTES, 'UTF-8'); ?>">
                <button class="btn btn-danger" type="submit">Buscar</button>
            </div>
        </form>

        <!-- Botão para abrir o modal de cadastro -->
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCadastro">Novo Registro</button>
        <a href="exportar_pdf.php" class="btn btn-primary">Exportar PDF</a>

        <!-- Tabela de Registros -->
        <table class="table table-striped table-hover mt-3">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Nome de Usuário</th>
                    <th>Senha</th>
                    <th>Descrição</th>
                    <th>Site</th>
                    <th>Observações</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()) { 
            $decrypted_password = decryptPassword($row['senha']);
        ?>
            <tr>
                <td><?php echo htmlspecialchars($row['nome'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($row['nome_usuario'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td class="senha" data-senha="<?php echo htmlspecialchars($decrypted_password, ENT_QUOTES, 'UTF-8'); ?>">
                    
                </td>
                <td><?php echo htmlspecialchars($row['descricao'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($row['site'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($row['obs'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td>
                    <!-- Botão para abrir o modal de visualização -->
                    <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#modalVisualizar<?php echo $row['id']; ?>">
                        Visualizar
                    </button>

                    <!-- Botão para abrir o modal de edição -->
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalEditar<?php echo $row['id']; ?>">
                        Editar
                    </button>
                
                    <!-- Botão para abrir o modal de confirmação -->
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#confirmDeleteModal" data-id="<?php echo $row['id']; ?>">Excluir</button>

                </td>
            </tr>

                    <!-- Modal de Visualização -->
                    <div class="modal fade" id="modalVisualizar<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="modalVisualizarLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalVisualizarLabel">Visualizar Registro</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Nome:</strong> <?php echo htmlspecialchars($row['nome'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <p><strong>Nome de Usuário:</strong> <?php echo htmlspecialchars($row['nome_usuario'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <p><strong>Senha:</strong> <?php echo htmlspecialchars($decrypted_password, ENT_QUOTES, 'UTF-8'); ?></p>
                                    <p><strong>Descrição:</strong> <?php echo htmlspecialchars($row['descricao'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <p><strong>Site:</strong> <?php echo htmlspecialchars($row['site'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <p><strong>Observações:</strong> <?php echo htmlspecialchars($row['obs'], ENT_QUOTES, 'UTF-8'); ?></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal de Edição -->
                    <div class="modal fade" id="modalEditar<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalEditarLabel">Editar Registro</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="editar_registro.php" method="POST">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="nome<?php echo $row['id']; ?>" class="form-label">Nome</label>
                                            <input type="text" class="form-control" id="nome<?php echo $row['id']; ?>" name="nome" value="<?php echo htmlspecialchars($row['nome'], ENT_QUOTES, 'UTF-8'); ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="nome_usuario<?php echo $row['id']; ?>" class="form-label">Nome de Usuário</label>
                                            <input type="text" class="form-control" id="nome_usuario<?php echo $row['id']; ?>" name="nome_usuario" value="<?php echo htmlspecialchars($row['nome_usuario'], ENT_QUOTES, 'UTF-8'); ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="senha<?php echo $row['id']; ?>" class="form-label">Senha</label>
                                            <input type="password" class="form-control" id="senha<?php echo $row['id']; ?>" name="senha" placeholder="Digite a nova senha" required>
                                            <input type="hidden" name="senha_atual" value="<?php echo htmlspecialchars($row['senha'], ENT_QUOTES, 'UTF-8'); ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="descricao<?php echo $row['id']; ?>" class="form-label">Descrição</label>
                                            <textarea class="form-control" id="descricao<?php echo $row['id']; ?>" name="descricao"><?php echo htmlspecialchars($row['descricao'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="site<?php echo $row['id']; ?>" class="form-label">Site</label>
                                            <input type="text" class="form-control" id="site<?php echo $row['id']; ?>" name="site" value="<?php echo htmlspecialchars($row['site'], ENT_QUOTES, 'UTF-8'); ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label for="obs<?php echo $row['id']; ?>" class="form-label">Observações</label>
                                            <textarea class="form-control" id="obs<?php echo $row['id']; ?>" name="obs"><?php echo htmlspecialchars($row['obs'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                        <button type="submit" class="btn btn-primary">Salvar alterações</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
            <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Modal de Cadastro -->
    <div class="modal fade" id="modalCadastro" tabindex="-1" aria-labelledby="modalCadastroLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalCadastroLabel">Novo Registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="cadastrar_registro.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="nome" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="nome" name="nome" required>
                        </div>
                        <div class="mb-3">
                            <label for="nome_usuario" class="form-label">Nome de Usuário</label>
                            <input type="text" class="form-control" id="nome_usuario" name="nome_usuario" required>
                        </div>
                        <div class="mb-3">
                            <label for="senha" class="form-label">Senha</label>
                            <input type="password" class="form-control" id="senha" name="senha" required>
                        </div>
                        <div class="mb-3">
                            <label for="descricao" class="form-label">Descrição</label>
                            <textarea class="form-control" id="descricao" name="descricao"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="site" class="form-label">Site</label>
                            <input type="text" class="form-control" id="site" name="site">
                        </div>
                        <div class="mb-3">
                            <label for="obs" class="form-label">Observações</label>
                            <textarea class="form-control" id="obs" name="obs"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


<!-- Modal Sobre -->
<div class="modal fade" id="modalSobre" tabindex="-1" aria-labelledby="modalSobreLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalSobreLabel">Sobre o Sistema Klauz - W</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h2>Klauz - W</h2>
                <p>Desenvolvido para gerenciar senhas de maneira segura e eficiente, permitindo a busca, cadastro, edição e visualização de registros.</p>
                <p>Desenvolvido PHP, MySQL e Bootstrap, o que facilita o seu uso.</p>
                <p>Por segurança o sistema permite somente um usuário como proprietário.</p><br>
                <p>Versão 1.0.0</p>
                <p>Data: 2024-08-17</p>
                <p>Desenvolvedor: <a href="https://www.mariomedeiros.eti.br" target="_blank">Mario Medeiros - Disaster Developer</a></p>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>


<!-- Modal de confirmação de exclusão -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Você tem certeza de que deseja excluir este registro?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteButton">Excluir</button>
            </div>
        </div>
    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Variável para armazenar o ID do registro a ser excluído
    var recordId;

    // Evento para abrir o modal e definir o ID do registro a ser excluído
    document.addEventListener('DOMContentLoaded', function () {
        var deleteButtons = document.querySelectorAll('[data-bs-target="#confirmDeleteModal"]');
        
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                recordId = this.getAttribute('data-id');
            });
        });
    });

    // Evento para confirmar a exclusão
    document.getElementById('confirmDeleteButton').addEventListener('click', function() {
        if (recordId) {
            // Fazendo uma requisição AJAX para excluir o registro
            fetch('delete_record.php?id=' + recordId, {
                method: 'GET'
            })
            .then(response => response.text())
            .then(result => {
                // Aqui você pode adicionar o código para atualizar a tabela ou redirecionar
                // após a exclusão bem-sucedida
                window.location.reload(); // Recarregar a página para refletir a exclusão
            })
            .catch(error => console.error('Erro:', error));
        }
    });
</script>

</body>
</html>
