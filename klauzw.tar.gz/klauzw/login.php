<?php
include('conexao.php');
session_start(); // Iniciar a sessão

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $senha = $_POST['senha'];

    // Verifica se a senha corresponde à do proprietário
    $sql = "SELECT * FROM proprietario LIMIT 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $proprietario = $result->fetch_assoc();

        // Verifica a senha usando password_verify
        if (password_verify($senha, $proprietario['senha'])) {
            // Senha correta, definir a sessão
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id'] = $proprietario['id']; // Armazena o ID do proprietário na sessão (opcional)
            $_SESSION['user_name'] = $proprietario['nome']; // Armazena o nome do proprietário na sessão (opcional)

            // Redireciona para a dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Senha incorreta.";
        }
    } else {
        echo "Proprietário não encontrado.";
    }

    $conn->close();
}
?>
<!-- HTML Formulário de Login -->
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #d4e5f6; /* Cor de fundo */
            height: 100vh; /* Altura total da viewport */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background-color: #a1b2c3; /* Fundo branco para o formulário */
            padding: 2rem; /* Espaçamento interno */
            border-radius: 8px; /* Bordas arredondadas */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2); /* Sombra */
            max-width: 400px; /* Largura máxima do formulário */
            width: 100%;
        }
    </style>
        <style>
        /* Define o estilo da imagem de fundo */
        body {
            /* Define a imagem de fundo */
            background-image: url('logo.png');
            
            /* Faz com que a imagem fique fixa na tela */
            background-attachment: fixed;

            /* Faz com que a imagem cubra toda a área da página */
            background-size: cover;

            /* Centraliza a imagem de fundo */
            background-position: center;

            /* Define a opacidade do fundo */
            background-repeat: no-repeat;

            /* Define uma cor de fundo semitransparente para melhorar a legibilidade do texto */
            /*background-color: rgba(255, 255, 255, 0.5); /* Altere a cor e a opacidade conforme necessário */
        }
    </style>
</head>
<body>
    
<div class="login-container">
    <h2 class="text-center">Sistema Klauz-W</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="senha" class="form-label">Senha:</label>
            <input type="password" class="form-control" id="senha" name="senha" required>
        </div>
        <button type="submit" class="btn btn-secondary w-100">Acessar</button>
    </form>
</div>
</body>
</html>