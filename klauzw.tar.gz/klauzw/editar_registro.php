<?php
include('conexao.php');

function encryptPassword($password) {
    $cipher = "aes-256-cbc";
    $key = "senha-a-ser-definida"; // A mesma chave secreta utilizada no cadastro
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = openssl_random_pseudo_bytes($ivlen);
    $ciphertext = openssl_encrypt($password, $cipher, $key, 0, $iv);
    return base64_encode($iv . $ciphertext); // Combine IV com a senha criptografada
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $nome_usuario = $_POST['nome_usuario'];
    $senha = $_POST['senha'];
    $descricao = $_POST['descricao'];
    $site = $_POST['site'];
    $obs = $_POST['obs'];

    // Verificar se a senha foi alterada
    if (!empty($senha)) {
        $senha = encryptPassword($senha); // Criptografa a nova senha
        $sql = "UPDATE registros SET nome='$nome', nome_usuario='$nome_usuario', senha='$senha', 
                descricao='$descricao', site='$site', obs='$obs' WHERE id=$id";
    } else {
        // Se a senha não foi alterada, não atualizar o campo senha
        $sql = "UPDATE registros SET nome='$nome', nome_usuario='$nome_usuario', 
                descricao='$descricao', site='$site', obs='$obs' WHERE id=$id";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Registro atualizado com sucesso.";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
    header("Location: dashboard.php");
    exit();
}
?>
