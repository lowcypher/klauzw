<?php
include('conexao.php');

$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$email = $_POST['email'];
$senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Hash da senha

// Insere o novo proprietário na tabela
$sql = "INSERT INTO proprietario (nome, sobrenome, email, senha) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nome, $sobrenome, $email, $senha);
$stmt->execute();

// Redireciona para a página de login após o cadastro
header('Location: login.php');
exit();
?>
