<?php
session_start();

// Verifica se o proprietário já está logado
if (isset($_SESSION['proprietario_logado']) && $_SESSION['proprietario_logado'] === true) {
    // Redireciona para o dashboard
    header("Location: dashboard.php");
    exit();
} else {
    // Redireciona para a página de login
    header("Location: login.php");
    exit();
}
