<?php
include 'conexao.php'; // Inclua o arquivo de conexão

// Verifique se o ID do registro foi passado
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Prepare a consulta SQL para excluir o registro
    $sql = "DELETE FROM registros WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    // Verifique se a preparação da consulta foi bem-sucedida
    if ($stmt) {
        // Execute a consulta com o ID do registro
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo 'Registro excluído com sucesso.';
        } else {
            echo 'Erro ao excluir o registro: ' . $stmt->error;
        }
        $stmt->close();
    } else {
        echo 'Erro ao preparar a consulta: ' . $conn->error;
    }
} else {
    echo 'ID do registro não especificado.';
}

// Feche a conexão com o banco de dados
$conn->close();
?>
