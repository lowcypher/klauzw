<?php
include('conexao.php');

function encryptPassword($password) {
    $cipher = "aes-256-cbc";
    $key = "senha-a-ser-definida"; // Escolha uma chave secreta segura
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = openssl_random_pseudo_bytes($ivlen);
    $ciphertext = openssl_encrypt($password, $cipher, $key, 0, $iv);
    return base64_encode($iv . $ciphertext); // Combine IV com a senha criptografada
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $nome_usuario = $_POST['nome_usuario'];
    $senha = encryptPassword($_POST['senha']); // Criptografa a senha antes de armazenar
    $descricao = $_POST['descricao'];
    $site = $_POST['site'];
    $obs = $_POST['obs'];

    $sql = "INSERT INTO registros (nome, nome_usuario, senha, descricao, site, obs) 
            VALUES ('$nome', '$nome_usuario', '$senha', '$descricao', '$site', '$obs')";

    if ($conn->query($sql) === TRUE) {
        echo "Novo registro cadastrado com sucesso.";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
    header("Location: dashboard.php");
    exit();
}
?>
