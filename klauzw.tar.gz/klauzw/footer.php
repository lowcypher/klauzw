<style type="text/css">
  logo {
  font: 18px Arial, sans-serif;
  display: inline-block;
  transform: rotate(180deg);
}
</style>
 
<!--<footer class="fixed-bottom"> -->
<footer class="bottom">  
    <div class="text-center p-1" style="background-color: rgba(0, 0, 0, 0.2)" >
        <p class="text-center" style='color:black'><b> <logo>&copy;</logo> <?php echo date("Y"); ?> - Sistema Klaus-W - </b>
        <a class="text-black" href="https://www.mariomedeiros.eti.br" target="_blank">Mario Medeiros - Disaster Developer</a>
        
          <!-- Mario Medeiros - Disaster Developer - Sistema PortaTreko</a></p> -->
          <!-- <h3><b> <font size="5">Sistema Editor TrogloEdita</font></h3></b> -->
      </div>
</footer>